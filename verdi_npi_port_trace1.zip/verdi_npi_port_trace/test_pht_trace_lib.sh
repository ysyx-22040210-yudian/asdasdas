#!/bin/bash
# Test script for tracing ysyx_22050058_pht module ports using -lib mode

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Run the NPI trace tool with -lib option
"$SCRIPT_DIR/npi_trace.sh" \
    -lib "/tmp/npc_build/simv.daidir/kdb.elab++" \
    -module "ysyx_22050058_pht" \
    -srcfile "../../vsrc/bpu/ysyx_22050058_pht.v" \
    > pht_trace_result.csv

echo "Trace completed. Results saved to pht_trace_result.csv"
echo ""
echo "First 20 lines of output:"
head -20 pht_trace_result.csv

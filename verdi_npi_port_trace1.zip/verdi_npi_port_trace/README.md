# verdi_npi_port_trace

用 Verdi NPI API 遍历指定模块的所有端口，追踪每个端口连接的 net 的驱动源（driver）和负载目标（load），输出为纯 CSV 文件。

## 依赖

- Verdi（已验证：Verdi_O-2018.09-SP2）
- 环境变量 `VERDI_HOME` 已设置

## 文件说明

```
verdi_npi_port_trace/
├── npi_trace.sh        # 入口脚本，解析参数、调用 verdi（TCL 版）
├── npi_port_trace.tcl  # NPI TCL 核心脚本
├── npi_port_trace.cpp  # NPI C++ 独立可执行文件版本
├── Makefile            # 编译 npi_port_trace 可执行文件
└── README.md
```

## TCL 版（npi_trace.sh）

### 使用方式

```bash
./npi_trace.sh \
  -module   <target_module>    # 要分析的目标模块名
  -srcfile  <target_module.v>  # 目标模块的 Verilog 源文件（用于解析端口方向）
  [-lib     <kdb.elab++ dir>]  # 加载已编译的 Verdi 库（与 -filelist/-top 二选一）
  [-filelist <filelist.f>]     # 设计文件列表（-f 格式，无 -lib 时必填）
  [-top      <top_module>]     # 顶层模块名（无 -lib 时必填）
  [-incdir  <include_dir>]     # 可选：+incdir 头文件目录（仅 debImport 模式有效）
  [-ports   <p1,p2,...>]       # 可选：只检查指定端口（逗号分隔），不加则检查全部端口
```

`-lib` 和 `-filelist/-top` 是两种互斥的设计加载方式：
- `-lib <kdb.elab++ dir>`：用 `debImport -elab` 加载已编译库，速度快。传 `simv.daidir/kdb.elab++` 目录，不是里面的 `work.lib++` 文件
- `-filelist + -top`：每次从源文件重新编译，适合没有预编译库的场景

```bash
# 用已编译的 kdb.elab++（推荐，速度快）
./npi_trace.sh \
  -lib /tmp/npc_build/simv.daidir/kdb.elab++ \
  -module ysyx_22050058 \
  -srcfile /abs/path/to/vsrc/ysyx_22050058.v \
  > result.csv

# 只查指定端口
./npi_trace.sh \
  -lib /tmp/npc_build/simv.daidir/kdb.elab++ \
  -module ysyx_22050058 \
  -srcfile /abs/path/to/vsrc/ysyx_22050058.v \
  -ports clock,io_master_awvalid \
  > result.csv
```

注意：`-srcfile` 必须使用绝对路径，Verdi batch 模式的工作目录与 shell 不同。

## C++ 独立可执行文件版本（npi_port_trace）

不依赖 Verdi batch 模式，直接链接 NPI 动态库，编译为独立可执行文件。

### 编译

```bash
export VERDI_HOME=/path/to/verdi
make
```

### 使用方式

```bash
# 加载 kdb.elab++ 目录（传目录本身，不是里面的 work.lib++ 文件）
./npi_port_trace \
  -elab /tmp/npc_build/simv.daidir/kdb.elab++ \
  -module ysyx_22050058 \
  > result.csv

# 只查指定端口
./npi_port_trace \
  -elab /tmp/npc_build/simv.daidir/kdb.elab++ \
  -module ysyx_22050058 \
  -ports clock,io_master_awvalid \
  > result.csv

# 也可以用 NPI 原生参数（透传给 npi_load_design）
./npi_port_trace \
  -lib work -path /tmp/npc_build/simv.daidir/kdb.elab++/work.lib++ \
  -top tb_top \
  -module ysyx_22050058 \
  > result.csv
```

运行时 Makefile 已通过 `-Wl,-rpath` 嵌入库路径，通常不需要手动设置 `LD_LIBRARY_PATH`。

### 参数说明

| 参数 | 说明 |
|------|------|
| `-elab <dir>` | 加载 `kdb.elab++` 目录（推荐） |
| `-module <mod>` | 目标模块名（必填） |
| `-ports p1,p2,...` | 只检查指定端口（可选，不加则检查全部） |
| 其他参数 | 透传给 `npi_load_design`（如 `-lib`, `-path`, `-top`） |

## 输出格式

CSV，5列：

| 列名 | 说明 |
|------|------|
| `inst_full_name` | 实例的完整层次路径，如 `tb_top.dut.my_module_u0` |
| `port_name` | 端口名 |
| `port_dir` | 端口方向：`input` / `output` / `inout` |
| `role` | `driver`（驱动该端口的信号）或 `load`（该端口驱动的信号） |
| `signal_full_name` | 对端信号的完整层次路径（instport 形式），空表示未连接或 bus port |

示例：

```
inst_full_name,port_name,port_dir,role,signal_full_name
tb_top.dut.my_mod_u0,clock,input,driver,tb_top.dut.clk
tb_top.dut.my_mod_u0,io_valid,output,driver,tb_top.dut.my_mod_u0.io_valid
tb_top.dut.my_mod_u0,io_valid,output,load,tb_top.dut.slave_u0.valid_i
```

## 已知限制

- **宽总线端口**（packed array，如 `[63:0] awaddr`）的 driver/load 为空，这是 NPI `npi_nl_trace_driver` 对 bus port 的限制。
- `signal_full_name` 是 instport 路径（`inst.portname` 形式），不是内部 wire 名。
- TCL 版需要在 Verdi 能读取的工作目录下运行（有 `novas.rc` 或 `novas.conf` 的目录）。

## 迁移到新项目

1. 将整个 `verdi_npi_port_trace/` 目录复制到新项目。
2. 准备好设计的 filelist（`-f` 格式，列出所有 `.v`/`.sv` 文件）或已编译的 `kdb.elab++`。
3. 确认 `VERDI_HOME` 已设置，运行 `make` 编译 C++ 版，或直接使用 TCL 版。

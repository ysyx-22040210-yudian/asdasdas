#!/bin/bash
# Debug test script to see why some ports are empty

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Running NPI trace with debug info..."
"$SCRIPT_DIR/npi_trace.sh" \
    -lib "/tmp/npc_build/simv.daidir/kdb.elab++" \
    -module "ysyx_22050058_pht" \
    -srcfile "../../vsrc/bpu/ysyx_22050058_pht.v" \
    > pht_trace_debug.csv

echo ""
echo "=== Results with debug info ==="
cat pht_trace_debug.csv
echo ""
echo "=== Ports with EXPR or ERROR ==="
grep -E "EXPR:|ERROR:" pht_trace_debug.csv || echo "No expression/error entries found"

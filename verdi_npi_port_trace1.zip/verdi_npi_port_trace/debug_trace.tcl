# Debug script to see what signals we're actually tracing

source npi_port_trace.tcl

# Get the instance
set inst_path "tb_top.dut.ysyx_22050058_u0.ysyx_22050058_pipeline_u0.ysyx_22050058_bpu_u0.ysyx_22050058_gshare_u0.ysyx_22050058_pht_u0"

# Get high-side connections
set port2highList {}
::npi_L1::npi_inst_port_2_high_conn_sig $inst_path port2highList

puts "=== High-side connections for pht_u0 ==="
foreach pair $port2highList {
    set ph [lindex $pair 0]
    set sigList [lindex $pair 1]
    
    # Get port name
    set portname ""
    catch {
        set info [::npi_L1::npi_nl_ut_get_hdl_info $ph]
        set portname [string trim [lindex [split $info ","] 1]]
    }
    
    puts "\nPort: $portname (handle: $ph)"
    puts "  Connected signals: [llength $sigList]"
    
    foreach sig_hdl $sigList {
        set signame ""
        catch {
            set sig_info [::npi_L1::npi_nl_ut_get_hdl_info $sig_hdl]
            set signame [string trim [lindex [split $sig_info ","] 1]]
        }
        puts "    Signal: $signame (handle: $sig_hdl)"
        
        # Try to trace driver
        if { $signame ne "" } {
            set driverList {}
            set r [::npi_L1::npi_nl_trace_driver $signame driverList 0 1]
            puts "      trace_driver result: $r, drivers found: [llength $driverList]"
            foreach drv $driverList {
                set drvname ""
                catch {
                    set drv_info [::npi_L1::npi_nl_ut_get_hdl_info $drv]
                    set drvname [string trim [lindex [split $drv_info ","] 1]]
                }
                puts "        -> $drvname"
            }
        }
    }
}

exit

#!/bin/bash
echo "Testing corrected tracing logic..."
./npi_trace.sh \
    -lib "/tmp/npc_build/simv.daidir/kdb.elab++" \
    -module "ysyx_22050058_pht" \
    -srcfile "../../vsrc/bpu/ysyx_22050058_pht.v"

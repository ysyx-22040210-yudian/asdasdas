#!/bin/bash
exec env LD_LIBRARY_PATH="/home/synopsys/verdi/Verdi_O-2018.09-SP2/share/NPI/lib/LINUX64:$LD_LIBRARY_PATH" "$(dirname "$0")/npi_port_trace" "$@"

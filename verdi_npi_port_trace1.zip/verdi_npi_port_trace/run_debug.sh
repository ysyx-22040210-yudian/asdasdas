#!/bin/bash
if [ -z "$VERDI_HOME" ]; then
    echo "[ERROR] VERDI_HOME is not set."
    exit 1
fi

export NPI_LIB="/tmp/npc_build/simv.daidir/kdb.elab++"
export NPI_MODULE="ysyx_22050058_pht"
export NPI_SRCFILE="../../vsrc/bpu/ysyx_22050058_pht.v"

verdi -batch -nologo -play debug_trace.tcl 2>&1

#!/bin/bash
# Test script for tracing ysyx_22050058_pht module ports

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Run the NPI trace tool
"$SCRIPT_DIR/npi_trace.sh" \
    -filelist "$SCRIPT_DIR/test_filelist.f" \
    -incdir "D:/VMshare/CPU_CORE/ysyx/npc/vsrc/include" \
    -top "ysyx_22050058" \
    -module "ysyx_22050058_pht" \
    -srcfile "D:/VMshare/CPU_CORE/ysyx/npc/vsrc/bpu/ysyx_22050058_pht.v" \
    > pht_trace_result.csv

echo "Trace completed. Results saved to pht_trace_result.csv"
echo ""
echo "First 20 lines of output:"
head -20 pht_trace_result.csv

#!/bin/bash
# Run this script from an environment where VERDI_HOME is set
# (e.g., after sourcing Synopsys environment setup)

cd "$(dirname "$0")"

echo "Testing PHT module port tracing with corrected driver/loader logic..."
echo ""

./npi_trace.sh \
    -lib "/tmp/npc_build/simv.daidir/kdb.elab++" \
    -module "ysyx_22050058_pht" \
    -srcfile "../../vsrc/bpu/ysyx_22050058_pht.v" \
    > pht_trace_corrected.csv

if [ $? -eq 0 ]; then
    echo "Trace completed successfully!"
    echo ""
    echo "=== Results ==="
    cat pht_trace_corrected.csv
    echo ""
    echo "=== Summary ==="
    echo "Total lines: $(wc -l < pht_trace_corrected.csv)"
    echo "Drivers found: $(grep ',driver,' pht_trace_corrected.csv | grep -v 'NO_DRIVER' | wc -l)"
    echo "Loads found: $(grep ',load,' pht_trace_corrected.csv | grep -v 'NO_LOAD' | wc -l)"
    echo "NO_DRIVER entries: $(grep 'NO_DRIVER' pht_trace_corrected.csv | wc -l)"
    echo "NO_LOAD entries: $(grep 'NO_LOAD' pht_trace_corrected.csv | wc -l)"
else
    echo "Trace failed. Check error messages above."
    exit 1
fi

#!/bin/bash
# npi_trace.sh — run npi_port_trace.tcl via verdi -batch, output port driver/load CSV
#
# Usage:
#   ./npi_trace.sh -filelist <filelist.f> -incdir <include_dir> \
#                  -top <top_module> -module <target_module> -srcfile <module.v> \
#                  [-ports <port1,port2,...>]
#   ./npi_trace.sh -filelist ... > result.csv


SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TCL="$SCRIPT_DIR/npi_port_trace.tcl"

if [ -z "$VERDI_HOME" ]; then
    echo "[ERROR] VERDI_HOME is not set." >&2
    exit 1
fi

FILELIST=""
INCDIR=""
TOP=""
MODULE=""
SRCFILE=""
PORTS=""
LIB=""

while [ $# -gt 0 ]; do
    case "$1" in
        -filelist) FILELIST="$2"; shift 2 ;;
        -incdir)   INCDIR="$2";   shift 2 ;;
        -top)      TOP="$2";      shift 2 ;;
        -module)   MODULE="$2";   shift 2 ;;
        -srcfile)  SRCFILE="$2";  shift 2 ;;
        -ports)    PORTS="$2";    shift 2 ;;
        -lib)      LIB="$2";      shift 2 ;;
        *) echo "[WARN] unknown arg: $1" >&2; shift ;;
    esac
done

if [ -z "$MODULE" ] || [ -z "$SRCFILE" ]; then
    echo "Usage: $0 -module <mod> -srcfile <src.v> [-lib <work.lib++>] [-filelist <f> -top <top>] [-incdir <dir>] [-ports <p1,p2,...>]" >&2
    echo "  -lib and (-filelist + -top) are mutually exclusive ways to load the design." >&2
    exit 1
fi
if [ -z "$LIB" ] && { [ -z "$FILELIST" ] || [ -z "$TOP" ]; }; then
    echo "[ERROR] Either -lib <work.lib++> or both -filelist and -top must be provided." >&2
    exit 1
fi

TMPOUT="$(mktemp /tmp/npi_trace_out.XXXXXX.csv)"

export NPI_FILELIST="$FILELIST"
export NPI_TOP="$TOP"
export NPI_MODULE="$MODULE"
export NPI_SRCFILE="$SRCFILE"
export NPI_INCDIR="$INCDIR"
export NPI_PORTS="$PORTS"
export NPI_LIB="$LIB"
export NPI_OUTFILE="$TMPOUT"

verdi -batch -nologo -play "$TCL" >/dev/null 2>&1

if [ ! -s "$TMPOUT" ]; then
    echo "[ERROR] no output generated" >&2
    rm -f "$TMPOUT"
    exit 1
fi

cat "$TMPOUT"
rm -f "$TMPOUT"

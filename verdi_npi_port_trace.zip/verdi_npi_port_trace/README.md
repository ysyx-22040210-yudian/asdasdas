# verdi_npi_port_trace

用 Verdi NPI TCL API 遍历指定模块的所有端口，追踪每个端口连接的 net 的驱动源（driver）和负载目标（load），输出为纯 CSV 文件。

## 依赖

- Verdi（已验证：Verdi_O-2018.09-SP2）
- 环境变量 `VERDI_HOME` 已设置

## 文件说明

```
verdi_npi_port_trace/
├── npi_trace.sh        # 入口脚本，解析参数、调用 verdi
├── npi_port_trace.tcl  # NPI TCL 核心脚本
└── README.md
```

## 使用方式

```bash
./npi_trace.sh \
  -module   <target_module>    # 要分析的目标模块名
  -srcfile  <target_module.v>  # 目标模块的 Verilog 源文件（用于解析端口方向）
  [-lib     <work.lib++>]      # 加载已编译的 Verdi 库（与 -filelist/-top 二选一）
  [-filelist <filelist.f>]     # 设计文件列表（-f 格式，无 -lib 时必填）
  [-top      <top_module>]     # 顶层模块名（无 -lib 时必填）
  [-incdir  <include_dir>]     # 可选：+incdir 头文件目录（仅 debImport 模式有效）
  [-ports   <p1,p2,...>]       # 可选：只检查指定端口（逗号分隔），不加则检查全部端口
```

`-lib` 和 `-filelist/-top` 是两种互斥的设计加载方式：
- `-lib work.lib++`：用 `debImport -elab <kdb.elab++目录>` 加载已编译库，速度快，推荐在有 VCS/Verdi 编译产物时使用。`-lib` 参数传 `simv.daidir/kdb.elab++` 目录，不是里面的 `work.lib++` 文件
- `-filelist + -top`：每次从源文件重新编译，适合没有预编译库的场景

输出到 stdout，重定向到文件即可得到纯 CSV：

```bash
# 用已编译的 work.lib++（推荐，速度快）
./npi_trace.sh \
  -lib /tmp/npc_build/simv.daidir/kdb.elab++/work.lib++ \
  -module ysyx_22050058 \
  -srcfile vsrc/ysyx_22050058.v \
  > result.csv

# 只查指定端口
./npi_trace.sh \
  -lib /tmp/npc_build/simv.daidir/kdb.elab++/work.lib++ \
  -module ysyx_22050058 \
  -srcfile vsrc/ysyx_22050058.v \
  -ports clock,io_master_awvalid \
  > result.csv
```

## 输出格式

CSV，5列：

| 列名 | 说明 |
|------|------|
| `inst_full_name` | 实例的完整层次路径，如 `tb_top.dut.my_module_u0` |
| `port_name` | 端口名 |
| `port_dir` | 端口方向：`input` / `output` / `inout` |
| `role` | `driver`（驱动该端口的信号）或 `load`（该端口驱动的信号） |
| `signal_full_name` | 对端信号的完整层次路径（instport 形式），空表示未连接或 bus port |

示例：

```
inst_full_name,port_name,port_dir,role,signal_full_name
tb_top.dut.my_mod_u0,clock,input,driver,tb_top.dut.clk
tb_top.dut.my_mod_u0,io_valid,output,driver,tb_top.dut.my_mod_u0.io_valid
tb_top.dut.my_mod_u0,io_valid,output,load,tb_top.dut.slave_u0.valid_i
```

## 已知限制

- **宽总线端口**（packed array，如 `[63:0] awaddr`）的 driver/load 为空，这是 NPI `npi_nl_trace_driver` 对 bus port 的限制。
- `signal_full_name` 是 instport 路径（`inst.portname` 形式），不是内部 wire 名。
- 需要在 Verdi 能读取的工作目录下运行（有 `novas.rc` 或 `novas.conf` 的目录）。

## 迁移到新项目

1. 将整个 `verdi_npi_port_trace/` 目录复制到新项目。
2. 准备好设计的 filelist（`-f` 格式，列出所有 `.v`/`.sv` 文件）。
3. 确认 `VERDI_HOME` 已设置，在 Verdi 工作目录下执行 `npi_trace.sh`。

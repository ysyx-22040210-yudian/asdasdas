# npi_port_trace.tcl
#
# For each instance of a given module, iterate its ports, trace drivers
# and loads for the connected net, and output CSV.
#
# CSV columns: inst_full_name, port_name, port_dir, role, signal_full_name
#
# Usage (via npi_trace.sh):
#   verdi -batch -nologo -play npi_port_trace.tcl \
#         +tclarg_filelist <filelist.f> \
#         +tclarg_incdir   <include_dir> \
#         +tclarg_top      <top_module> \
#         +tclarg_module   <target_module> \
#         +tclarg_srcfile  <module_source.v>
#
# All +tclarg_* values are passed as Tcl variables by Verdi's +tclarg mechanism.

if { [info exists env(VERDI_HOME)] } {
    source $env(VERDI_HOME)/share/NPI/L1/TCL/npi_L1.tcl
} elseif { [info exists env(NPIL1_PATH)] } {
    source $env(NPIL1_PATH)/npi_L1.tcl
} else {
    puts stderr "ERROR: VERDI_HOME or NPIL1_PATH must be set"
    exit 1
}

# -----------------------------------------------------------------------
# Required arguments — read from environment variables
# -lib mode: only NPI_MODULE and NPI_SRCFILE are required
# -filelist mode: NPI_FILELIST, NPI_TOP, NPI_MODULE, NPI_SRCFILE are required
# -----------------------------------------------------------------------
set use_lib [expr { [info exists env(NPI_LIB)] && $env(NPI_LIB) ne "" }]

foreach { varname envname } {
    target_mod NPI_MODULE
    srcfile    NPI_SRCFILE
} {
    if { ![info exists env($envname)] || $env($envname) eq "" } {
        puts stderr "ERROR: environment variable $envname is not set"
        debExit
    }
    set $varname $env($envname)
}

if { !$use_lib } {
    foreach { varname envname } {
        filelist   NPI_FILELIST
        top_module NPI_TOP
    } {
        if { ![info exists env($envname)] || $env($envname) eq "" } {
            puts stderr "ERROR: environment variable $envname is not set (required when not using -lib)"
            debExit
        }
        set $varname $env($envname)
    }
}
set incdir [expr { [info exists env(NPI_INCDIR)] ? $env(NPI_INCDIR) : "" }]

# Optional: comma-separated list of ports to filter (empty = all ports)
set port_filter {}
if { [info exists env(NPI_PORTS)] && $env(NPI_PORTS) ne "" } {
    foreach p [split $env(NPI_PORTS) ","] {
        set p [string trim $p]
        if { $p ne "" } { lappend port_filter $p }
    }
}

# Output file (written by shell via NPI_OUTFILE env var)
if { [info exists env(NPI_OUTFILE)] && $env(NPI_OUTFILE) ne "" } {
    set outfh [open $env(NPI_OUTFILE) w]
} else {
    set outfh stdout
}

# -----------------------------------------------------------------------
# Load design
# -----------------------------------------------------------------------
if { $use_lib } {
    if { [catch { debImport -elab $env(NPI_LIB) } e] } {
        puts stderr "ERROR: debImport -elab failed: $e"
        debExit
    }
} elseif { $incdir ne "" } {
    debImport -f $filelist +incdir+$incdir -top $top_module -sv
} else {
    debImport -f $filelist -top $top_module -sv
}

# -----------------------------------------------------------------------
# Build port -> direction map by parsing the module source file
# -----------------------------------------------------------------------
proc build_port_dir_map { srcfile target_mod } {
    set fh [open $srcfile r]
    set lines [split [read $fh] "\n"]
    close $fh

    set map {}
    set in_module 0
    foreach line $lines {
        set t [string trim $line]
        if { [regexp {^module\s+} $t] && [string match "module ${target_mod} *" $t] ||
             [regexp {^module\s+} $t] && [string match "module ${target_mod}(*" $t] ||
             [regexp {^module\s+} $t] && [string match "module ${target_mod}#*" $t] ||
             $t eq "module ${target_mod}" } {
            set in_module 1
        }
        if { $in_module } {
            if { [regexp {^\s*(input|output|inout)\s+(?:reg\s+)?(?:wire\s+)?(?:\[[^\]]*\]\s+)?(\w+)} $t -> dir portname] } {
                dict set map $portname $dir
            }
            if { [regexp {\);\s*$} $t] || [regexp {^endmodule} $t] } {
                set in_module 0
            }
        }
    }
    return $map
}

# -----------------------------------------------------------------------
# Get ordered port list from npi_mod_inst_get_io
# Returns list of port names in declaration order.
# -----------------------------------------------------------------------
proc get_port_list { inst_path } {
    set ioList {}
    if { [catch {
        ::npi_L1::npi_mod_inst_get_io $inst_path ioList
    } e] } {
        puts stderr "WARNING: npi_mod_inst_get_io failed for $inst_path: $e"
        return {}
    }
    set names {}
    foreach h $ioList {
        if { [catch {
            set info [::npi_L1::npi_ut_get_hdl_info $h]
            # format: "npiIODecl, portname, {file : line}"
            set portname [string trim [lindex [split $info ","] 1]]
            if { $portname ne "" } { lappend names $portname }
        }] } {}
    }
    return $names
}

# -----------------------------------------------------------------------
# Resolve a driver/load handle to its full signal name
# -----------------------------------------------------------------------
proc hdl_to_name { hdl } {
    set info ""
    catch { set info [::npi_L1::npi_nl_ut_get_hdl_info $hdl] }
    return [string trim [lindex [split $info ","] 1]]
}

# -----------------------------------------------------------------------
# Process one instance: emit CSV rows for all its ports
# -----------------------------------------------------------------------
proc process_instance { inst_path parent_path instname port_dir_map port_filter outfh } {
    set port_list [get_port_list $inst_path]
    if { [llength $port_list] == 0 } {
        puts stderr "WARNING: no ports found for $inst_path"
        return
    }

    foreach portname $port_list {
        # Skip if port filter is active and this port is not in the list
        if { [llength $port_filter] > 0 && [lsearch -exact $port_filter $portname] < 0 } {
            continue
        }

        set dir "unknown"
        if { [dict exists $port_dir_map $portname] } {
            set dir [dict get $port_dir_map $portname]
        }

        # Get instport handle (parent-side) -> connected net in parent scope
        set iph ""
        if { [catch {
            set iph [::npi_L1::npi_nl_instport_handle_by_nl_name $parent_path $instname $portname]
        }] } { set iph "" }

        if { $iph eq "" || $iph == 0 } {
            puts $outfh "$inst_path,$portname,$dir,driver,"
            continue
        }

        set nh ""
        if { [catch {
            set nh [::npi_L1::npi_nl_port_instport_2_net $iph]
        }] } { set nh "" }

        if { $nh eq "" || $nh == 0 } {
            puts $outfh "$inst_path,$portname,$dir,driver,"
            continue
        }

        set ninfo [::npi_L1::npi_nl_ut_get_hdl_info $nh]
        set netname [string trim [lindex [split $ninfo ","] 1]]

        # Trace drivers
        set sigList {}
        set r [::npi_L1::npi_nl_trace_driver $netname sigList 0 0]
        if { $r == 1 && [llength $sigList] > 0 } {
            foreach hdl $sigList {
                set sig [hdl_to_name $hdl]
                puts $outfh "$inst_path,$portname,$dir,driver,$sig"
            }
        } else {
            puts $outfh "$inst_path,$portname,$dir,driver,"
        }

        # Trace loads
        set loadList {}
        set r2 [::npi_L1::npi_nl_trace_load $netname loadList 0 0]
        if { $r2 == 1 && [llength $loadList] > 0 } {
            foreach hdl $loadList {
                set sig [hdl_to_name $hdl]
                puts $outfh "$inst_path,$portname,$dir,load,$sig"
            }
        }
    }
}

# -----------------------------------------------------------------------
# Find all instances of target_mod and process each
# -----------------------------------------------------------------------
set port_dir_map [build_port_dir_map $srcfile $target_mod]

set hdlList {}
if { [catch {
    ::npi_L1::npi_find_inst_with_def_wildcard "" $target_mod hdlList
} e] } {
    puts stderr "ERROR: npi_find_inst_with_def_wildcard failed: $e"
    debExit
}

if { [llength $hdlList] == 0 } {
    puts stderr "ERROR: no instances of module '$target_mod' found"
    debExit
}

# Print CSV header
puts $outfh "inst_full_name,port_name,port_dir,role,signal_full_name"

foreach ih $hdlList {
    # Get instance full path from npi_ut_get_hdl_info
    # format: "npiNlHierInst, full.path, (null)" — but this returns empty for inst handles
    # Use npi_nl_ut_get_hdl_info instead
    set inst_path ""
    if { [catch {
        set info [::npi_L1::npi_ut_get_hdl_info $ih]
        set inst_path [string trim [lindex [split $info ","] 1]]
    }] } {}

    if { $inst_path eq "" } {
        puts stderr "WARNING: could not get path for instance handle $ih, skipping"
        continue
    }

    # Derive parent path and instance name
    set parts [split $inst_path "."]
    set instname   [lindex $parts end]
    set parent_path [join [lrange $parts 0 end-1] "."]

    process_instance $inst_path $parent_path $instname $port_dir_map $port_filter $outfh
}

if { $outfh ne "stdout" } { close $outfh }
debExit

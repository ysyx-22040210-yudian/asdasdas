# Verdi NPI Port Tracing Tool

A tool for tracing port connections and signal drivers/loads in Verilog designs using Synopsys Verdi NPI (Netlist Programming Interface) APIs.

## Features

- Trace all ports of a target module instance
- Identify signal drivers and loads for each port
- Support both elaborated database (`.lib++`) and RTL source files
- Optional keyword-based filtering
- CSV output format for easy analysis

## Requirements

- Synopsys Verdi with NPI support
- `VERDI_HOME` environment variable set
- Python 2.7+ or 3.x (for filtering functionality)
- Bash shell

## Files

- `npi_port_trace.tcl` - Main TCL script using Verdi NPI APIs
- `npi_trace.sh` - Shell wrapper for running the TCL script
- `trace_and_filter.sh` - Integrated script with keyword filtering
- `filter_trace.py` - Python script for filtering CSV output
- `trace_id.sh` - Example script for tracing a specific module
- `npi_port_trace.cpp` - C++ standalone executable version
- `Makefile` - Build C++ version

## Usage

### Basic Tracing

Trace all ports of a module using elaborated database:

```bash
./npi_trace.sh \
    -lib "/path/to/simv.daidir/kdb.elab++" \
    -module "module_name" \
    > output.csv
```

Trace specific ports only:

```bash
./npi_trace.sh \
    -lib "/path/to/simv.daidir/kdb.elab++" \
    -module "module_name" \
    -ports "port1,port2,port3" \
    > output.csv
```

### Trace with Filtering

Generate both full trace and filtered results:

```bash
./trace_and_filter.sh \
    -module "module_name" \
    -lib "/path/to/simv.daidir/kdb.elab++" \
    -keywords "Memory,RegCombo,Register"
```

This creates:
- `module_name_full.csv` - Complete trace results
- `module_name_filtered.csv` - Rows containing any of the keywords

Custom output filename:

```bash
./trace_and_filter.sh \
    -module "module_name" \
    -lib "/path/to/simv.daidir/kdb.elab++" \
    -keywords "instbuffer,regfile" \
    -output custom_name.csv
```

### Standalone Filtering

Filter an existing CSV file:

```bash
python filter_trace.py input.csv output.csv "keyword1" "keyword2"
```

### C++ Standalone Version

Compile:

```bash
export VERDI_HOME=/path/to/verdi
make
```

Run:

```bash
./npi_port_trace \
    -elab /tmp/npc_build/simv.daidir/kdb.elab++ \
    -module ysyx_22050058 \
    > result.csv
```

## Output Format

CSV with the following columns:

- `inst_full_name` - Full hierarchical instance path
- `port_name` - Port name
- `role` - Either "driver" or "load"
- `signal_full_name` - Full path of the connected signal

Example:

```csv
inst_full_name,port_name,role,signal_full_name
tb_top.dut.cpu.id_u0,clk,driver,tb_top.tb_top/Always0:15-15/Combo.O0
tb_top.dut.cpu.id_u0,clk,load,cpu.id_u0.id/Always1:97-106/Combo.clk
tb_top.dut.cpu.id_u0,pc_i,driver,cpu.instbuffer_u0.instbuffer/SigOp5:122-122/ComboMemory_buffer[7:0].OH_pc_o[63:0]
tb_top.dut.cpu.id_u0,pc_i,load,cpu.id_u0.id/Always1:97-106/Combo.pc_i[63:0]
```

## Parameters

### npi_trace.sh

- `-module <name>` - Target module name (required)
- `-lib <path>` - Path to elaborated database `kdb.elab++` (required unless using -filelist)
- `-filelist <file>` - RTL filelist (alternative to -lib)
- `-top <module>` - Top module name (required with -filelist)
- `-incdir <dir>` - Include directory for RTL compilation
- `-ports <list>` - Comma-separated port names to trace (optional, traces all if omitted)

Note: `-srcfile` parameter is deprecated and optional (port direction is obtained via NPI API)

### trace_and_filter.sh

All parameters from `npi_trace.sh` plus:

- `-keywords <list>` - Comma-separated keywords for filtering (required)
- `-output <file>` - Output filename for filtered results (optional, defaults to `<module>_filtered.csv`)

## Examples

### Example 1: Trace ID Stage Module

```bash
./npi_trace.sh \
    -lib "/tmp/npc_build/simv.daidir/kdb.elab++" \
    -module "ysyx_22050058_id" \
    > id_full_trace.csv
```

### Example 2: Find Register Connections

```bash
./trace_and_filter.sh \
    -module "ysyx_22050058_id" \
    -lib "/tmp/npc_build/simv.daidir/kdb.elab++" \
    -keywords "RegCombo,Register,_r"
```

### Example 3: Trace Specific Ports

```bash
./npi_trace.sh \
    -lib "/tmp/npc_build/simv.daidir/kdb.elab++" \
    -module "ysyx_22050058_pht" \
    -ports "clk,rst,we,waddr,wdata" \
    > pht_write_ports.csv
```

### Example 4: Find Memory-Related Signals

```bash
./trace_and_filter.sh \
    -module "ysyx_22050058_dcache" \
    -lib "/tmp/npc_build/simv.daidir/kdb.elab++" \
    -keywords "Memory,SRAM,buffer" \
    -output dcache_memory.csv
```

## How It Works

1. **Load Design**: Uses Verdi NPI to load the elaborated design database
2. **Find Instance**: Locates the target module instance in the hierarchy
3. **Get Ports**: Retrieves all port handles for the instance
4. **Trace Connections**: For each port:
   - Gets high-side (parent scope) and low-side (child scope) connections
   - Traces drivers using `npi_nl_trace_driver`
   - Traces loads using `npi_nl_trace_load`
5. **Format Output**: Converts signal handles to readable hierarchical names
6. **Filter (optional)**: Applies keyword filtering to extract relevant signals

## Signal Path Format

Signal paths are formatted as: `module/block:line1-line2/type.signal`

- `module` - Module or scope name
- `block` - Code block (Always, Combo, Init, etc.)
- `line1-line2` - Source line range
- `type` - Signal type (RegCombo, Memory, Combo, etc.)
- `signal` - Signal name with bit range

Example: `ysyx_22050058_pipeline/Always6:1005-1066/RegCombo.wb_inst1bhr_r[12:0]`

## Troubleshooting

### VERDI_HOME not set

```bash
# Source your Synopsys environment setup
source /path/to/synopsys/setup.sh
```

### No output generated

- Verify the elaborated database path exists
- Check that the module name matches exactly (case-sensitive)
- Ensure the module is instantiated in the design

### Python syntax error

The filter script is compatible with both Python 2.7+ and 3.x.

## Known Limitations

- Wide bus ports (packed arrays like `[63:0] awaddr`) may have empty driver/load due to NPI `npi_nl_trace_driver` limitations on bus ports
- `signal_full_name` shows instport paths (`inst.portname` format), not internal wire names
- TCL version requires running in a directory where Verdi can read design files

## Migration to New Projects

1. Copy the entire `verdi_npi_port_trace/` directory to your project
2. Prepare design filelist or compiled `kdb.elab++`
3. Ensure `VERDI_HOME` is set
4. Run `make` to compile C++ version, or use TCL version directly

## License

Internal tool for CPU design verification and analysis.

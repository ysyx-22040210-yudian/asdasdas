#!/bin/bash
# Trace ysyx_22050058_id module

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Tracing ysyx_22050058_id module..."
"$SCRIPT_DIR/npi_trace.sh" \
    -lib "../../obj_dir/simv.daidir/kdb.elab++" \
    -module "ysyx_22050058_id" \
    > id_trace_result.csv

if [ $? -eq 0 ]; then
    echo "Trace completed successfully!"
    echo ""
    echo "=== First 30 lines of results ==="
    head -30 id_trace_result.csv
    echo ""
    echo "=== Summary ==="
    echo "Total lines: $(wc -l < id_trace_result.csv)"
    echo "Total ports: $(($(wc -l < id_trace_result.csv) - 1))"
    echo "Input ports with drivers: $(grep ',input,driver,' id_trace_result.csv | wc -l)"
    echo "Output ports with loads: $(grep ',output,load,' id_trace_result.csv | wc -l)"
else
    echo "Trace failed. Check error messages above."
    exit 1
fi
